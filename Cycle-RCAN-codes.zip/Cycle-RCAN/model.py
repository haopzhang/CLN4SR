import torch.nn.functional as F
from torch import nn
import torch
import math


class ResidualBlock(nn.Module):

    def __init__(self, channels):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        self.relu1 = nn.ReLU()
        self.conv2 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)

    def forward(self, x):
        residual = self.conv1(x)
        residual = self.relu1(residual)
        residual = self.conv2(x)

        return x + residual


class UpsampleBlock(nn.Module):
    def __init__(self, channel, upscale):
        super(UpsampleBlock, self).__init__()
        self.conv1 = nn.Conv2d(channel, channel * upscale * upscale, kernel_size=3, padding=1)
        self.up1 = nn.PixelShuffle(upscale)
        self.relu1 = nn.ReLU()

    def forward(self, x):
        x = self.conv1(x)
        x = self.up1(x)
        x = self.relu1(x)
        return x

class DownsampleBlock(nn.Module):
    def __init__(self,channel,scale):
        super(DownsampleBlock,self).__init__()
        self.down1=nn.AvgPool2d(kernel_size=(scale,scale),stride=scale)
        self.conv1=nn.Conv2d(channel,64,kernel_size=3,padding=1)
        self.relu1=nn.ReLU()

    def forward(self,x):
        x=self.down1(x)
        x=self.conv1(x)
        x=self.relu1(x)
        return x



class G1(nn.Module):
    def __init__(self,n_residual_blocks):
        self.n_residual_blocks=n_residual_blocks
        super(G1,self).__init__()
        self.block1=nn.Sequential(
            nn.Conv2d(3,64,kernel_size=3,padding=1),
            nn.ReLU()
        )
        for i in range(self.n_residual_blocks):
            self.add_module('residual_block'+str(i+1),ResidualBlock(64))
        self.block3=nn.Conv2d(64,64,kernel_size=3,padding=1)
        self.block4=UpsampleBlock(64,3)
        self.block5=nn.Conv2d(64,3,kernel_size=9,padding=4)


    def forward(self, x):
        block1=self.block1(x)
        block2=block1.clone()
        for i in range(self.n_residual_blocks):
            block2=self.__getattr__('residual_block'+str(i+1))(block2)
        block3=self.block3(block2)
        block4=self.block4(block1+block3)
        block5=self.block5(block4)
        return block5



class G2(nn.Module):
    def __init__(self,n_residual_block):
        self.n_residual_block=n_residual_block
        super(G2,self).__init__()
        self.block1=nn.Sequential(
            nn.Conv2d(3,64,kernel_size=3,padding=1),
            nn.ReLU()
        )
        self.block2=DownsampleBlock(64,3)
        for i in range(n_residual_block):
            self.add_module('residual_block'+str(i+1),ResidualBlock(64))
        self.block4=nn.Conv2d(64,64,kernel_size=3,padding=1)
        self.block5=nn.Sequential(
            nn.Conv2d(64,64,kernel_size=3,padding=1),
            nn.ReLU(),
            nn.Conv2d(64,3,kernel_size=9,padding=4)
        )

    def forward(self, x):
        block1=self.block1(x)
        block2=self.block2(block1)
        block3=block2.clone()
        for i in range(self.n_residual_block):
            block3=self.__getattr__('residual_block'+str(i+1))(block3)
        block4=self.block4(block3)
        block5=self.block5(block4+block2)

        return block5







