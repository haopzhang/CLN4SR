RCAN_train_PROBA.py应该是训练代码
 训练和测试需要结合options文件夹中的.json文件，设置包括数据路径，网络参数在内的参数
之前是在实验室的机器linux系统下跑通的代码，并进行了训练和测试
CUDA_VISIBLE_DEVICES=2 python 训练.py -opt ./options/train/xxxx.json
