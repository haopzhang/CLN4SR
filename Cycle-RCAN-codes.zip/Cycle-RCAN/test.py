import argparse, time, os
import imageio
import torch
import options.options as option
from utils import util
from data import create_dataloader
from data import create_dataset
import model
from collections import OrderedDict
from torch.autograd import Variable

def get_current_visual(LR,SR, rgb_range,need_np=True):
    """
    return LR SR (HR) images
    """
    out_dict = OrderedDict()
    out_dict['LR'] = LR.data[0].float().cpu()
    out_dict['SR'] = SR.data[0].float().cpu()
    if need_np:  out_dict['LR'], out_dict['SR'] = util.Tensor2np([out_dict['LR'], out_dict['SR']],
                                                                 rgb_range)
    return out_dict


def _overlap_crop_forward( x, scale, model, shave=10, min_size=100000, bic=None):
    """
    chop for less memory consumption during test
    """
    n_GPUs = 2
    scale = scale
    b, c, h, w = x.size()
    h_half, w_half = h // 2, w // 2
    h_size, w_size = h_half + shave, w_half + shave
    lr_list = [
        x[:, :, 0:h_size, 0:w_size],
        x[:, :, 0:h_size, (w - w_size):w],
        x[:, :, (h - h_size):h, 0:w_size],
        x[:, :, (h - h_size):h, (w - w_size):w]]

    if bic is not None:
        bic_h_size = h_size * scale
        bic_w_size = w_size * scale
        bic_h = h * scale
        bic_w = w * scale

        bic_list = [
            bic[:, :, 0:bic_h_size, 0:bic_w_size],
            bic[:, :, 0:bic_h_size, (bic_w - bic_w_size):bic_w],
            bic[:, :, (bic_h - bic_h_size):bic_h, 0:bic_w_size],
            bic[:, :, (bic_h - bic_h_size):bic_h, (bic_w - bic_w_size):bic_w]]

    if w_size * h_size < min_size:
        sr_list = []
        for i in range(0, 4, n_GPUs):
            lr_batch = torch.cat(lr_list[i:(i + n_GPUs)], dim=0)
            if bic is not None:
                bic_batch = torch.cat(bic_list[i:(i + n_GPUs)], dim=0)

            sr_batch_temp = model(lr_batch)

            if isinstance(sr_batch_temp, list):
                sr_batch = sr_batch_temp[-1]
            else:
                sr_batch = sr_batch_temp

            sr_list.extend(sr_batch.chunk(n_GPUs, dim=0))
    else:
        sr_list = [
            _overlap_crop_forward(patch,scale=scale,model=model, shave=shave, min_size=min_size) \
            for patch in lr_list
        ]

    h, w = scale * h, scale * w
    h_half, w_half = scale * h_half, scale * w_half
    h_size, w_size = scale * h_size, scale * w_size
    shave *= scale

    output = x.new(b, c, h, w)
    output[:, :, 0:h_half, 0:w_half] \
        = sr_list[0][:, :, 0:h_half, 0:w_half]
    output[:, :, 0:h_half, w_half:w] \
        = sr_list[1][:, :, 0:h_half, (w_size - w + w_half):w_size]
    output[:, :, h_half:h, 0:w_half] \
        = sr_list[2][:, :, (h_size - h + h_half):h_size, 0:w_half]
    output[:, :, h_half:h, w_half:w] \
        = sr_list[3][:, :, (h_size - h + h_half):h_size, (w_size - w + w_half):w_size]

    return output

def main():
    parser = argparse.ArgumentParser(description='Test Super Resolution Models')
    parser.add_argument('-opt', type=str, required=True, help='Path to options JSON file.')
    opt = option.parse(parser.parse_args().opt)
    opt = option.dict_to_nonedict(opt)

    # initial configure
    scale = opt['scale']
    degradation=opt['degradation']

    #create test dataloader
    bm_names=[]
    test_loaders=[]
    for _,dataset_opt in sorted(opt['datasets'].items()):
        test_set=create_dataset(dataset_opt)
        test_loader=create_dataloader(test_set,dataset_opt)
        test_loaders.append(test_loader)
        print('===>Test Dataset :[%s] Number of images:[%d]'%(test_set.name(),len(test_set)))
        bm_names.append(test_set.name())
    #load model
    model_path=opt['solver']['pretrained_path']
    netG1=model.G1(16)
    netG1.load_state_dict(torch.load(model_path))
    netG1.eval()

    for bm, test_loader in zip(bm_names,test_loaders):
        print("Test set:[%s]"%bm)
        sr_list=[]
        path_list=[]
        for iter, batch in enumerate(test_loader):
            with torch.no_grad():
                LR_img = Variable(batch['LR'])
                SR=_overlap_crop_forward(x=LR_img,scale=3,model=netG1)
                if isinstance(SR,list):
                    SR=SR[-1]
            print("[%d] is ok.",iter)
            visuals=get_current_visual(LR_img,SR,opt['rgb_range'])
            sr_list.append(visuals['SR'])
            path_list.append(os.path.basename(batch['LR_path'][0]))

        save_img_path=os.path.join('./results/SR/'+bm,degradation,"x%d"%scale)
        if not os.path.exists(save_img_path):os.makedirs(save_img_path)
        for img,name in zip(sr_list,path_list):
            imageio.imwrite(os.path.join(save_img_path,name),img)
    print("=====================================================")
    print("====>Finished!")


if __name__ =='__main__':
    main()



