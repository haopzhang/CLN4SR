import argparse, random
from tqdm import tqdm

import torch
import options.options as option
from data import create_dataloader
from data import create_dataset
import model
from torch.autograd import Variable
import torch.nn as nn
import torch.optim as optim


def main():
    parser=argparse.ArgumentParser(description='Train Super Resolution Model')
    parser.add_argument('-opt',type=str,required=True,help='Path to options Json file')
    opt = option.parse(parser.parse_args().opt)
    #random seed
    seed=0
    if seed is None: seed = random.randint(1,10000)
    print('==>Random Seed : [%d]'%seed)
    random.seed(seed)
    torch.manual_seed(seed)

    #create train and val dataloader
    for phase,dataset_opt in sorted(opt['datasets'].items()):
        if phase == 'train':
            train_set = create_dataset(dataset_opt)
            train_loader = create_dataloader(train_set, dataset_opt)
            print('===> Train Dataset: %s   Number of images: [%d]' % (train_set.name(), len(train_set)))
            if train_loader is None: raise ValueError("[Error] The training data does not exist")

        elif phase == 'val':
            val_set = create_dataset(dataset_opt)
            val_loader = create_dataloader(val_set, dataset_opt)
            print('===> Val Dataset: %s   Number of images: [%d]' % (val_set.name(), len(val_set)))

        else:
            raise NotImplementedError("[Error] Dataset phase [%s] in *.json is not recognized." % phase)

        netG1=model.G1(16)
        netG2=model.G2(5)
        cyc_loss = nn.MSELoss()
        idt_loss=nn.MSELoss()
        if torch.cuda.is_available():
            netG1.cuda()
            netG2.cuda()
            cyc_loss.cuda()
            idt_loss.cuda()
        optimizerG1=optim.Adam(netG1.parameters(),lr=1e-4)
        optimizerG2=optim.Adam(netG2.parameters(),lr=1e-4)

        NUM_EPOCH=int(opt['num_epochs'])
        start_epoch=1
        minloss = 1000000000000

        ##############################
        #multistep
        scheduler1=torch.optim.lr_scheduler.MultiStepLR(optimizerG1,milestones=[50,80],gamma=0.6)
        scheduler2=torch.optim.lr_scheduler.MultiStepLR(optimizerG2,milestones=[50,80],gamma=0.6)
        ###############################

        for epoch in range(start_epoch,NUM_EPOCH):
            train_bar=tqdm(train_loader)
            running_results = {'batch_sizes': 0, 'loss':0}

            netG1.train()
            netG2.train()

            for item,batch in enumerate(train_bar):
                batch_size=batch['LR'].size(0)
                running_results['batch_sizes']+=batch_size

                ###################
                #update G1 and G2
                netG1.zero_grad()
                netG2.zero_grad()
                hr_r_img=Variable(batch['HR_r'])#feipeidui
                lr_img=Variable(batch['LR'])
                hr_img=Variable(batch['HR'])

                if torch.cuda.is_available():
                    hr_r_img=hr_r_img.cuda()
                    lr_img=lr_img.cuda()
                    hr_img=hr_img.cuda()
                y_i=netG1(lr_img)
                x_ip=netG2(y_i)
                loss_f_cyc=cyc_loss(x_ip,lr_img)
                x_i=netG2(hr_r_img)
                y_ip=netG1(x_i)
                loss_b_cyc=cyc_loss(y_ip,hr_r_img)
                loss_cyc=loss_b_cyc+loss_f_cyc
                y_down=netG1(lr_img)
                loss_idt=idt_loss(y_down,hr_img)
                l=2*loss_idt+loss_cyc
                l.backward()
                optimizerG1.step()
                optimizerG2.step()
                running_results['loss']+=l.item()*batch_size
                with open('CYC_infrared_loss.txt', mode='a') as f:
                    f.write(str(running_results['loss'] / running_results['batch_sizes']) + ' ')
                train_bar.set_description(desc='[%d/%d]  loss: %.4f'%(
                    epoch,NUM_EPOCH,running_results['loss'] / running_results['batch_sizes'])
                )
            scheduler1.step()
            scheduler2.step()
            with open('CYC_infrared_loss.txt', mode='a') as f:
                f.write('\n')
            print('==>[epoch:%d  loss:%.4f]' %(epoch,running_results['loss'] / running_results['batch_sizes']))
            torch.save(netG1.state_dict(),'CYC_epochs_infrared/net_G1_epoch_%d.pth'% epoch)
            #torch.save(netG2.state_dict(),'epochs/net_G2_epoch_%d.pth'% epoch)
            if running_results['loss'] / running_results['batch_sizes'] < minloss:
                torch.save(netG1.state_dict(), 'CYC_epochs_infrared/net_G1_best.pth')
                print('best epoch is %d.' % epoch)
                minloss = running_results['loss'] / running_results['batch_sizes']







if __name__=='__main__':
    main()