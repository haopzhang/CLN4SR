import argparse, random
from tqdm import tqdm

import torch
import options.options as option
from data import create_dataloader
from data import create_dataset
import model
import RCAN_model
from torch.autograd import Variable
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
from collections import OrderedDict
from utils import util
import pandas as pd
import os

def get_current_visual(LR,SR,HR,rgb_range, need_np=True, need_HR=True):
    """
    return LR SR (HR) images
    """
    out_dict = OrderedDict()
    out_dict['LR'] = LR.data[0].float().cpu()
    out_dict['SR'] = SR.data[0].float().cpu()
    if need_np:  out_dict['LR'], out_dict['SR'] = util.Tensor2np([out_dict['LR'], out_dict['SR']],
                                                                 rgb_range)
    if need_HR:
        out_dict['HR'] = HR.data[0].float().cpu()
        out_dict['HR'] = util.Tensor2np([out_dict['HR']],rgb_range)[0]
    return out_dict


def _overlap_crop_forward( x, scale, model, shave=10, min_size=100000, bic=None):
    """
    chop for less memory consumption during test
    """
    n_GPUs = 2
    scale = scale
    b, c, h, w = x.size()
    h_half, w_half = h // 2, w // 2
    h_size, w_size = h_half + shave, w_half + shave
    lr_list = [
        x[:, :, 0:h_size, 0:w_size],
        x[:, :, 0:h_size, (w - w_size):w],
        x[:, :, (h - h_size):h, 0:w_size],
        x[:, :, (h - h_size):h, (w - w_size):w]]

    if bic is not None:
        bic_h_size = h_size * scale
        bic_w_size = w_size * scale
        bic_h = h * scale
        bic_w = w * scale

        bic_list = [
            bic[:, :, 0:bic_h_size, 0:bic_w_size],
            bic[:, :, 0:bic_h_size, (bic_w - bic_w_size):bic_w],
            bic[:, :, (bic_h - bic_h_size):bic_h, 0:bic_w_size],
            bic[:, :, (bic_h - bic_h_size):bic_h, (bic_w - bic_w_size):bic_w]]

    if w_size * h_size < min_size:
        sr_list = []
        for i in range(0, 4, n_GPUs):
            lr_batch = torch.cat(lr_list[i:(i + n_GPUs)], dim=0)
            if bic is not None:
                bic_batch = torch.cat(bic_list[i:(i + n_GPUs)], dim=0)

            sr_batch_temp = model(lr_batch)

            if isinstance(sr_batch_temp, list):
                sr_batch = sr_batch_temp[-1]
            else:
                sr_batch = sr_batch_temp

            sr_list.extend(sr_batch.chunk(n_GPUs, dim=0))
    else:
        sr_list = [
            _overlap_crop_forward(patch,scale=scale,model=model, shave=shave, min_size=min_size) \
            for patch in lr_list
        ]

    h, w = scale * h, scale * w
    h_half, w_half = scale * h_half, scale * w_half
    h_size, w_size = scale * h_size, scale * w_size
    shave *= scale

    output = x.new(b, c, h, w)
    output[:, :, 0:h_half, 0:w_half] \
        = sr_list[0][:, :, 0:h_half, 0:w_half]
    output[:, :, 0:h_half, w_half:w] \
        = sr_list[1][:, :, 0:h_half, (w_size - w + w_half):w_size]
    output[:, :, h_half:h, 0:w_half] \
        = sr_list[2][:, :, (h_size - h + h_half):h_size, 0:w_half]
    output[:, :, h_half:h, w_half:w] \
        = sr_list[3][:, :, (h_size - h + h_half):h_size, (w_size - w + w_half):w_size]

    return output

def main():
    parser=argparse.ArgumentParser(description='Train Super Resolution Model')
    parser.add_argument('-opt',type=str,required=True,help='Path to options Json file')
    opt = option.parse(parser.parse_args().opt)
    #random seed
    seed=0
    if seed is None: seed = random.randint(1,10000)
    print('==>Random Seed : [%d]'%seed)
    random.seed(seed)
    torch.manual_seed(seed)

    #create train and val dataloader
    for phase, dataset_opt in sorted(opt['datasets'].items()):
        if phase == 'train':
            train_set = create_dataset(dataset_opt)
            train_loader = create_dataloader(train_set, dataset_opt)
            print('===> Train Dataset: %s   Number of images: [%d]' % (train_set.name(), len(train_set)))
            if train_loader is None: raise ValueError("[Error] The training data does not exist")

        elif phase == 'val':
            val_set = create_dataset(dataset_opt)
            val_loader = create_dataloader(val_set, dataset_opt)
            print('===> Val Dataset: %s   Number of images: [%d]' % (val_set.name(), len(val_set)))

        else:
            raise NotImplementedError("[Error] Dataset phase [%s] in *.json is not recognized." % phase)

    netG1=RCAN_model.RCAN()
    netG2=model.G2(5)
    cyc_loss = nn.MSELoss()
    idt_loss=nn.MSELoss()
    if torch.cuda.is_available():
        print("cuda is available")
        netG1.cuda()
        netG2.cuda()
        cyc_loss.cuda()
        idt_loss.cuda()
    optimizerG1=optim.Adam(netG1.parameters(),lr=1e-4)
    optimizerG2=optim.Adam(netG2.parameters(),lr=1e-4)

    NUM_EPOCH=int(opt['num_epochs'])
    start_epoch=1
    pre_best_psnr=0
    ##############################
    # multistep
    scheduler1 = torch.optim.lr_scheduler.MultiStepLR(optimizerG1, milestones=[50, 80], gamma=0.6)
    scheduler2 = torch.optim.lr_scheduler.MultiStepLR(optimizerG2, milestones=[50, 80], gamma=0.6)
    ###############################
    ###record######
    record={'train_loss':[],
            'val_loss':[],
            'psnr':[],
            'ssim':[],
            'lr':[]}

    for epoch in range(start_epoch,NUM_EPOCH):
        train_bar=tqdm(train_loader)
        running_results = {'batch_sizes': 0, 'loss':0}

        netG1.train()
        netG2.train()

        for item,batch in enumerate(train_bar):

            batch_size=batch['LR'].size(0)

            running_results['batch_sizes']+=batch_size

            ###################
            #update G1 and G2
            netG1.zero_grad()
            netG2.zero_grad()
            lrbi_img=Variable(batch['LRBI'])
            lr_img=Variable(batch['LR'])
            hr_img=Variable(batch['HR'])

            if torch.cuda.is_available():
                lrbi_img=lrbi_img.cuda()
                lr_img=lr_img.cuda()
                hr_img=hr_img.cuda()
            y_i=netG1(lr_img)
            x_ip=netG2(y_i)
            loss_f_cyc=cyc_loss(x_ip,lr_img)
            x_i=netG2(hr_img)
            y_ip=netG1(x_i)
            loss_b_cyc=cyc_loss(y_ip,hr_img)
            loss_cyc=loss_b_cyc+loss_f_cyc
            y_down=netG1(lrbi_img)
            loss_idt=idt_loss(y_down,hr_img)
            l=2*loss_idt+loss_cyc
            l.backward()
            optimizerG1.step()
            optimizerG2.step()
            running_results['loss']+=l.item()*batch_size
            with open('RCAN_infrared_loss.txt', mode='a') as f:
                f.write(str(running_results['loss'] / running_results['batch_sizes']) + ' ')
            train_bar.set_description(desc='[%d/%d]  loss: %.4f'%(
                    epoch,NUM_EPOCH,running_results['loss']/running_results['batch_sizes'])
            )
        record['train_loss'].append(running_results['loss']/running_results['batch_sizes'])
        record['lr'].append(optimizerG1.param_groups[0]['lr'])

        print('===>Validating...')
        psnr_list=[]
        ssim_list=[]
        val_loss_list=[]
        netG1.eval()
        for iter,batch in enumerate(val_loader):
            with torch.no_grad():
                LR_img = Variable(batch['LRBI'])
                SR = _overlap_crop_forward(x=LR_img, scale=3, model=netG1)
                if isinstance(SR, list):
                    SR = SR[-1]
            HR_img = Variable(batch['HR'])
            val_loss=idt_loss(HR_img,SR)
            val_loss_list.append(val_loss.item())
            visuals = get_current_visual(LR_img, SR, HR_img,opt['rgb_range'])
            psnr,ssim=util.calc_metrics(visuals['SR'],visuals['HR'],crop_border=opt['scale'])
            psnr_list.append(psnr)
            ssim_list.append(ssim)

        record['val_loss'].append(sum(val_loss_list)/len(val_loss_list))
        record['psnr'].append(sum(psnr_list)/len(psnr_list))
        record['ssim'].append(sum(ssim_list)/len(ssim_list))

        scheduler1.step()
        scheduler2.step()
        with open('RCAN_infrared_loss.txt', mode='a') as f:
            f.write('\n')
        print('==>[epoch:%d  loss:%.4f]' %(epoch,running_results['loss']/running_results['batch_sizes']))
        torch.save(netG1.state_dict(),'RCAN_epochs_infrared/net_G1_last.pth')
        torch.save(netG2.state_dict(),'RCAN_epochs_infrared/net_G2_last.pth')

        if sum(psnr_list)/len(psnr_list) > pre_best_psnr:
            torch.save(netG1.state_dict(), 'RCAN_epochs_infrared/net_G1_best.pth')
            print('best epoch is %d.' % epoch)
            pre_best_psnr = sum(psnr_list)/len(psnr_list)

        data_frame=pd.DataFrame(
            data={'train_loss':record['train_loss'],
                    'val_loss':record['val_loss'],
                    'psnr':record['psnr'],
                    'ssim':record['ssim'],
                    'lr':record['lr']
                    },
                index=range(1,epoch+1)
            )
        data_frame.to_csv(os.path.join(opt['record_dir'],'train_record.csv'),index_label='epoch')










if __name__=='__main__':
    main()